# The Work Task Variation Problem

This repository contains a MiniZinc model and a set of generated
insances for the Work Task Variation problem.