Integrated Healthcare Timetabling

The model was developed to compete in the Integrated Healthcare Timetabling
Competition 2024 (https://ihtc2024.github.io/) and is released under the terms
of the MIT license (see LICENSE.txt).

The competition organizers provided 30 instances to the public for testing.
By enriching the original data slightly (for easier consumption by the MiniZinc
model), the instances in the folder public-instances/ were obtained.
These instances are released under the terms of the MIT license (see LICENSE.txt)
with kind permission of the competition organizers.

Contact: Michael Marte <informarte@freenet.de>
