MiniZinc models and data files
accompanies CPAIOR 2020 abstract "A New Constraint Programming Model and Solving for the Cyclic Hoist Scheduling Problem", and Constraints journal article of the same title

copyright (c) 2020 M. Wallace and N. Yorke-Smith
contact: n.yorke-smith@tudelft.nl
released under CC BY-NC-SA license (https://creativecommons.org/licenses/by-nc-sa/4.0/)

https://doi.org/10.4121/uuid:211d5c86-ee65-455c-a8ab-9265aab1e289