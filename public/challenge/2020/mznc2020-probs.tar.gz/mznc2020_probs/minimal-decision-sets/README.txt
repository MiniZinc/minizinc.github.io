
We need two more parameters to run these.

I suggest trying

	n = 5;
	n = 10; 
	n = 20;
	
and 

	Lambda = I div 2;
	Lambda = I div 20;
	Lambda = I div 200;
